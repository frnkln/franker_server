package com.jesuschat.privatechat;

import java.io.IOException;
import java.util.HashMap;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArraySet;

import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;

import org.json.JSONException;
import org.json.JSONObject;


@ServerEndpoint("/chat/{username}")

public class OneToOneChat {

	static ConcurrentHashMap<String, String> usersMap = new ConcurrentHashMap<String, String>();
	
	private static final Set<OneToOneChat> connections = new CopyOnWriteArraySet<>();
	
	private String username;
	private Session session;
	
	public OneToOneChat() {
		username = null;
		
	}

	@OnOpen
	public void start(Session session, @PathParam("username") String user) {
		
		this.session = session;
		connections.add(this); 
		this.username = user;
		 addUserInMap(session.getId(), username); 
		 String usersListAll = getOnlineUsersList(); 
		 String sltoAll=preparegetListAll(usersListAll);
		 broadcast(sltoAll);
	}

	@OnClose
	public void end(Session session) {
		connections.remove(this); 
		removeUserInMap(session.getId(), username);
	    String usersListAll = getOnlineUsersList(); 
		String sltoAll=preparegetListAll(usersListAll);
		broadcast(sltoAll);
	}

	@OnMessage
	public void incoming(Session session, String message) {
		String action = extractAction(message);
		switch (action) {

		case "list":
		    String usersList = getOnlineUsersList(); 
			String sendList=preparegetList(usersList);
			broadcast(sendList, session.getId()); 
			break;
		case "chat":
			String from = extractFrom(message); 
			String to = extractTo(message); 
			String actualMessage = extractActualMessage(message);
			sendMessageToUser(to, from, actualMessage,"one"); 
			break;
			
        case "permission":
			String from_per = extractFrom(message);
			String to_per = extractTo(message);
			String actualMessage_per = extractActualMessage(message);
			sendMessageToUser(to_per, from_per, actualMessage_per,"two");
			break;
       case "reject":
			String from_rej = extractFrom(message);
			String to_rej = extractTo(message);
			String actualMessage_rej = extractActualMessage(message);
			sendMessageToUser(to_rej, from_rej, actualMessage_rej,"three");
			break;
		default:
			break;
		}
	}

	private String preparegetList(String usersList) {
		String json=null;
		try {
			JSONObject jObj = new JSONObject();
		    jObj.put("getlist", usersList);
			jObj.put("filter", "list");
			json=jObj.toString();
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return json;
	}
	
	private String preparegetListAll(String usersList) {
		String json=null;
		try {
			JSONObject jObj = new JSONObject();
		    jObj.put("getlist", usersList);
			jObj.put("filter", "weblist");
			json=jObj.toString();
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return json;
	}
	
	

	private void sendMessageToUser(String to, String from, String actualMessage,String checker) {
		
		String toSessionId = getSessionIdOfUser(to);
		String messageToSend=null;
		if(checker.equalsIgnoreCase("one")){
		messageToSend = prepareMessage(to, from, actualMessage);
		}else if(checker.equalsIgnoreCase("two")){
			messageToSend = prepareMessagePermission(to, from, actualMessage);
		}else if(checker.equalsIgnoreCase("three")){
			messageToSend = prepareMessageReject(to, from, actualMessage);
		}
		else{
			
		}
		broadcast(messageToSend, toSessionId);
	}

	private void broadcast(String messageToSend, String toSessionId) {
		for (OneToOneChat client : connections) {
			try {
				synchronized (client) {
		
					if (client.session.getId().equals(toSessionId)) {
		
						client.session.getBasicRemote().sendText(messageToSend);
					}
				}
			} catch (IOException e) {
				connections.remove(client);
				try {
					client.session.close();
				} catch (IOException e1) {
				}
				String message = String.format("* %s %s", client.username,
						"has been disconnected.");
				broadcast(message);
			}
		}
	}

	private static void broadcast(String msg) {
		for (OneToOneChat client : connections) {
			try {
				synchronized (client) {
					client.session.getBasicRemote().sendText(msg); 
				}
			} catch (IOException e) {
				connections.remove(client);
				try {
					client.session.close();
				} catch (IOException e1) {
				}
				String message = String.format("* %s %s", client.username,
						"has been disconnected.");
				broadcast(message);
			}
		}
	}

	private String prepareMessage(String to, String from, String actualMessage) {
		String json=null;
		try {
			JSONObject jObj = new JSONObject();
		    jObj.put("flag", "message");
			jObj.put("filter", "chat");
			jObj.put("to", to);
			jObj.put("from", from);
			jObj.put("message", actualMessage);
			json=jObj.toString();
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return json;
	}
	private String prepareMessagePermission(String to, String from, String actualMessage) {
		String json=null;
		try {
			JSONObject jObj = new JSONObject();
		    jObj.put("flag", "message");
			jObj.put("filter", "permission");
			jObj.put("to", to);
			jObj.put("from", from);
			jObj.put("message", actualMessage);
			json=jObj.toString();
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return json;
	}
	
	private String prepareMessageReject(String to, String from, String actualMessage) {
		String json=null;
		try {
			JSONObject jObj = new JSONObject();
		    jObj.put("flag", "message");
			jObj.put("filter", "reject");
			jObj.put("to", to);
			jObj.put("from", from);
			jObj.put("message", actualMessage);
			json=jObj.toString();
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return json;
	}

	private String getSessionIdOfUser(String to) {
		if (usersMap.containsValue(to)) {
			for (String key : usersMap.keySet()) {
				if (usersMap.get(key).equals(to)) {
					return key;
				}
			}
		}
		return null;
	}

	

	private void addUserInMap(String id, String username) {
		usersMap.put(id, username);
	}

	private void removeUserInMap(String id, String user) {
		usersMap.remove(id);
	}


	private String extractActualMessage(String message) {
		String actualMsg=null;
		try {
			JSONObject jObj = new JSONObject(message);
		 actualMsg=jObj.getString("message");
		} catch (JSONException e) {
			e.printStackTrace();
		}
		
		return actualMsg;
	}

	private String extractTo(String message) {
		 String toMsg=null;
			try {
				JSONObject jObj = new JSONObject(message);
			 toMsg=jObj.getString("toname");
			} catch (JSONException e) {
				e.printStackTrace();
			}
			
			return toMsg;
	}

	private String extractFrom(String message) {
		 String fromMsg=null;
			try {
				JSONObject jObj = new JSONObject(message);
			 fromMsg=jObj.getString("fromname");
			} catch (JSONException e) {
				e.printStackTrace();
			}
			
			return fromMsg;
		
	}

	private String extractAction(String message) {
		 String action=null;
		try {
			JSONObject jObj = new JSONObject(message);
		 action=jObj.getString("action");
		} catch (JSONException e) {
			e.printStackTrace();
		}
		
		return action;	
	}


	
	private String getOnlineUsersList() {
		String usersList = new String();
		for (Entry<String, String> m : usersMap.entrySet()) {
			String iUser = m.getValue();
			if (usersList.toLowerCase().contains(iUser.toLowerCase())) {
				continue;
			} else {
				usersList = iUser + "-" + usersList;
			}
		}
		
		return usersList;
	}
}