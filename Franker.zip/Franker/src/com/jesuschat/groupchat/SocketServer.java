package com.jesuschat.groupchat;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import javax.naming.NamingException;
import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

import org.json.JSONException;
import org.json.JSONObject;

import com.google.common.collect.Maps;
import com.jndi.Connection.DBConnection;

import java.sql.*;

@ServerEndpoint("/groupchat")
public class SocketServer {

	Connection connection =null;
	
	public SocketServer() {
		if(connection==null){
			try {
				connection=DBConnection.getConnection();
			} catch (ClassNotFoundException | SQLException | NamingException e) {
				e.printStackTrace();
			}
		}
	}
	
	protected static final String HISTORY_SESSION = "historymessages";

	private static final Set<Session> sessions = Collections
			.synchronizedSet(new HashSet<Session>());

	private static final HashMap<String, String> nameSessionPair = new HashMap<String, String>();

	private JSONUtils jsonUtils = new JSONUtils();

	public static Map<String, String> getQueryMap(String query) {

		Map<String, String> map = Maps.newHashMap();
		if (query != null) {
			String[] params = query.split("&");
			for (String param : params) {
				String[] nameval = param.split("=");
				map.put(nameval[0], nameval[1]);
			}
		}
		return map;

	}

	
	@OnOpen
	public void onOpen(Session session) {

		Map<String, String> queryParams = getQueryMap(session.getQueryString());
		String name = "";
		ResultSet myResult = null;
		
		
		try {
			
			Statement myStmt = connection.createStatement();
//			myResult = myStmt
//					.executeQuery("SELECT * FROM(SELECT * FROM history order by historyID DESC limit 100)history order by historyID ASC");
		
			myResult = myStmt
					.executeQuery("SELECT * FROM history order by historyID ASC");
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		if (queryParams.containsKey("name")) {

			name = queryParams.get("name");
			try {
				name = URLDecoder.decode(name, "UTF-8");
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}

			nameSessionPair.put(session.getId(), name);
		}

		sessions.add(session);

		try {
			session.getBasicRemote().sendText(
					jsonUtils.getClientDetailsJson(session.getId(),
							"Your session details"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	
		try {
			sqlConnectionCall(myResult,session);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void sqlConnectionCall(ResultSet myResult,Session session) throws Exception {


		if (myResult != null) {

			while (myResult.next()) {
				session.getBasicRemote().sendText(jsonUtils.getMessagefromDB(session.getId(),myResult.getString("NAME"),myResult.getString("MESSAGE"),myResult.getString("TIME")));
				
			}
		}

	}

	@OnMessage
	public void onMessage(String message, Session session) {


		String msg = null;
		String name = null;
		String time=null;
		System.out.println("dating App entrys");

		try {
			JSONObject jObj = new JSONObject(message);
			msg = jObj.getString("message");
            time=getSystemTime();
		} catch (JSONException e) {
			e.printStackTrace();
		}
		name = nameSessionPair.get(session.getId());

		sendMessageToAll(session.getId(), nameSessionPair.get(session.getId()),
				msg,time, false, false);
		try {
			pushMessagesToDB(name, msg,time);
		} catch (Exception e) {
				e.printStackTrace();
		}

	}

	
	private String getSystemTime(){
		Date dt=new Date();
		return dt.toString();
	}
	
	private void pushMessagesToDB(String name, String msg,String time) throws Exception {

		String msgQuery = "INSERT INTO history(NAME,MESSAGE,TIME) values(?,?,?)";
		try {
			PreparedStatement preparedStmt = connection
					.prepareStatement(msgQuery);
			preparedStmt.setString(1, name);
			preparedStmt.setString(2, msg);
			preparedStmt.setString(3, time);
			preparedStmt.execute();
			preparedStmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}


	@OnClose
	public void onClose(Session session) {

		// removing the session from sessions list
		sessions.remove(session);
		try {
			if (!connection.isClosed())
				connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	private void sendMessageToAll(String sessionId, String name,
			String message,String time, boolean isNewClient, boolean isExit) {

	
		for (Session s : sessions) {
			String json = null;

				json = jsonUtils
						.getSendAllMessageJson(sessionId, name, message,time);

			try {
				s.getBasicRemote().sendText(json);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}