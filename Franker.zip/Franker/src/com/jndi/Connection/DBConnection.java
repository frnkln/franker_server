package com.jndi.Connection;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;


/**
 * @author Franklin Jino
 */
public class DBConnection
{

	public static Connection getConnection() throws SQLException, ClassNotFoundException, NamingException
	{
		
		// start
		
		// Obtain our environment naming context
		Context initCtx = new InitialContext();
		Context envCtx = (Context) initCtx.lookup("java:comp/env");

		// Look up our data source
		DataSource ds = (DataSource) envCtx.lookup("jdbc/groupchat");
	

		Connection connection = ds.getConnection();
        
		return connection;
	}
}

