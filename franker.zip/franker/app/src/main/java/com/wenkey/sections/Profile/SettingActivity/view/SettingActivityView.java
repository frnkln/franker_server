package com.wenkey.sections.Profile.SettingActivity.view;

/**
 * Created by Ali Assadi on 10/17/2017.
 */

public interface SettingActivityView {

}
