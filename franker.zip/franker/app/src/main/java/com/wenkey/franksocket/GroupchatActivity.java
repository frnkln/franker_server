package com.wenkey.franksocket;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.speech.RecognizerIntent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.codebutler.android_websockets.WebSocketClient;
import com.wenkey.R;
import com.wenkey.franksocket.Adapter.MessagesListAdapter;
import com.wenkey.franksocket.Model.MessageChat;
import com.wenkey.franksocket.Model.Utils;
import com.wenkey.franksocket.Model.WsConfig;

import org.json.JSONException;
import org.json.JSONObject;

import java.net.URI;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import okhttp3.OkHttpClient;


/**
 * Created by franklin on 25/06/2018 AD.
 */

public class GroupchatActivity extends AppCompatActivity {


    protected static final int RESULT_SPEECH = 1;
    public String voiceInput = null;

    RelativeLayout bottomwriteLayout, emonjiLayout;

    // Context context = this;
    private Button btnSend;
    private ImageButton btnVoice, emojiButton;
    private EditText inputMsg;
    private TextView textviewdaily;
    private MessagesListAdapter adapter;
    private List<MessageChat> listMessages;
    private ListView listViewMessages;
    public SharedPreferences sharedPreferences;
    private Utils utils;
    private String name = null;
    Handler handler = new Handler();
    private static final String TAG_SELF = "self", TAG_MESSAGE = "message";
    private final int REQ_CODE_SPEECH_INPUT_GROUP = 100;

    RelativeLayout.LayoutParams params, params1;

    Handler myHandler;

    WebSocketClient client;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_groupchat);
        initialize();

        utils = new Utils(this);
        name="Franklin";
        btnSend.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                hideKeyB();
                String inputdata = inputMsg.getText().toString().trim();
                if (inputdata.equals("")) {
                    Toast.makeText(GroupchatActivity.this,
                            "Please Enter Valid message", Toast.LENGTH_SHORT)
                            .show();
                } else {
                    ConnectivityManager con_manager = (ConnectivityManager) GroupchatActivity.this
                            .getSystemService(Context.CONNECTIVITY_SERVICE);

                    if (con_manager.getActiveNetworkInfo() != null
                            && con_manager.getActiveNetworkInfo().isAvailable()
                            && con_manager.getActiveNetworkInfo().isConnected()) {
                        if (inputdata!=null && !inputdata.equals("")) {
                            sendMessageToServer(utils
                                    .getSendMessageJSON(inputMsg.getText()
                                            .toString()));
                        } else {
                            showToast("Please enter the text");
                            inputMsg.setText("");
                        }
                    } else {
                        Toast.makeText(
                                GroupchatActivity.this,
                                "No network available.Please check your internet Connection",
                                Toast.LENGTH_SHORT).show();
                    }
                }
                inputMsg.setText("");
            }
        });
        btnVoice.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                voicetoSpeechgroup();
            }
        });

        listMessages = new ArrayList<MessageChat>();

        adapter = new MessagesListAdapter(this, listMessages);
        listViewMessages.setAdapter(adapter);


        /**
         * Creating web socket client. This will have callback methods
         * */
        client = new WebSocketClient(URI.create(WsConfig.URL_WEBSOCKET_GROUP
                + URLEncoder.encode(name)), new WebSocketClient.Listener() {
            @Override
            public void onConnect() {
                System.out.println("franklin");
            }

            /**
             * On receiving the message from web socket server
             * */
            @Override
            public void onMessage(String message) {
                System.out.println("parse message");
                parseMessage(message);
            }

            @Override
            public void onMessage(byte[] data) {

                // Message will be in JSON format
                parseMessage(bytesToHex(data));
                // System.out.println("my message passing in byte");
            }

            /**
             * Called when the connection is terminated
             * */
            @Override
            public void onDisconnect(int code, String reason) {
                System.out.println("disconnect code");
                // String message = String.format(Locale.US,
                // "Disconnected! Code: %d Reason: %s", code, reason);
                utils.storeSessionId(null);
                removeClient();
            }

            @Override
            public void onError(Exception error) {
                // Log.e(TAG, "Error! : " + error);
                removeClient();
            }

        }, null);

        client.connect();
    }



    private void hideKeyB() {
        InputMethodManager inputMethodManager = (InputMethodManager) this
                .getSystemService(Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(this.getCurrentFocus()
                .getWindowToken(), 0);
    }

    private void showToastLocal(String post) {
        Toast.makeText(this, post, Toast.LENGTH_SHORT).show();

    }


    private void removeClient() {

        if (client != null & client.isConnected()) {
            client.disconnect();
        }
    }



    private void initialize() {
        textviewdaily = (TextView) findViewById(R.id.biblewords);
        btnSend = (Button) findViewById(R.id.btnSend);
        btnVoice = (ImageButton) findViewById(R.id.voicebuttonone);
        inputMsg = (EditText) findViewById(R.id.inputMsg);
        listViewMessages = (ListView) findViewById(R.id.list_view_messages);
        bottomwriteLayout = (RelativeLayout) findViewById(R.id.bottombar_lay);
    }

    // Google Voice Chat API
    public void voicetoSpeechgroup() {

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Please talk");
        try {

            startActivityForResult(intent, REQ_CODE_SPEECH_INPUT_GROUP);
        } catch (ActivityNotFoundException a) {
            Toast.makeText(this, "not support", Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        // TODO Auto-generated method stub
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case REQ_CODE_SPEECH_INPUT_GROUP: {
                if (resultCode == Activity.RESULT_OK && null != data) {

                    ArrayList<String> result = data
                            .getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);

                    inputMsg.setText(result.get(0));
                }
                break;
            }

        }

    }

    // @Override
    // public void onActivityResult(int requestCode, int resultCode, Intent
    // data) {
    // super.onActivityResult(requestCode, resultCode, data);
    // System.out.println("called super");
    // switch (requestCode) {
    // case REQ_CODE_SPEECH_INPUT_GROUP: {
    // if (resultCode == Activity.RESULT_OK && null != data) {
    //
    // ArrayList<String> result = data
    // .getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
    // inputMsg.setText(result.get(0));
    // System.out.println("called1");
    // }
    // break;
    // }
    //
    // }
    // }
    private void sendMessageToServer(String message) {
        if (client != null && client.isConnected()) {
            client.send(message);
        }
    }

    private void parseMessage(final String msg) {

        try {
            JSONObject jObj = null;
            try {
                jObj = new JSONObject(msg);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            String flag = jObj.getString("flag");

            if (flag.equalsIgnoreCase(TAG_SELF)) {
                String sessionId = jObj.getString("sessionId");
                utils.storeSessionId(sessionId);

            } else if (flag.equalsIgnoreCase(TAG_MESSAGE)) {

                final String message = jObj.getString("message");
                final String fromName = jObj.getString("name");
                boolean isSelf;
                if (fromName.equalsIgnoreCase(this.name)) {
                    isSelf = true;
                } else {
                    isSelf = false;
                }

                if (fromName.equalsIgnoreCase("bible")) {

                    this.runOnUiThread(new Runnable() {

                        @Override
                        public void run() {
                            textviewdaily.setText(message);
                        }
                    });
                }
                MessageChat m = new MessageChat(fromName, message, isSelf);

                // Appending the message to chat list
                if (!fromName.equalsIgnoreCase("bible"))
                    appendMessage(m);

            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    // @Override
    // public void onStop() {
    // // TODO Auto-generated method stub
    // super.onStop();
    // if (client != null & client.isConnected()) {
    // client.disconnect();
    // }
    // }

    @Override
    public void onDestroy() {
        super.onDestroy();

        if (client != null & client.isConnected()) {
            client.disconnect();
        }
    }

    /**
     * Appending message to list view
     * */
    private void appendMessage(final MessageChat m) {
        if (this != null) {
            this.runOnUiThread(new Runnable() {

                @Override
                public void run() {

                    listMessages.add(m);

                    adapter.notifyDataSetChanged();
                    // Playing device's notification
                    // if (sessionid.matches("historyfakeCheck")) {
                    // playBeep();
                    // }
                }

            });
        }
    }

    private void showToast(final String message) {

        if (this != null) {
            this.runOnUiThread(new Runnable() {

                @Override
                public void run() {
                    if (this != null)
                        Toast.makeText(GroupchatActivity.this, message,
                                Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    /**
     * Plays device's default notification sound
     * */
    public void playBeep() {

        try {

            Uri notification = RingtoneManager
                    .getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            Ringtone r = RingtoneManager.getRingtone(this, notification);
            r.play();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    final protected static char[] hexArray = "0123456789ABCDEF".toCharArray();

    public static String bytesToHex(byte[] bytes) {
        char[] hexChars = new char[bytes.length * 2];
        for (int j = 0; j < bytes.length; j++) {
            int v = bytes[j] & 0xFF;
            hexChars[j * 2] = hexArray[v >>> 4];
            hexChars[j * 2 + 1] = hexArray[v & 0x0F];
        }
        return new String(hexChars);
    }

    // public static void getInputMessage(Emojicon emojicon) {
    //
    // EmojiconsFragment.input(inputMsg, emojicon);
    // }
    // public static void getCallBackSpace(View v) {
    //
    // EmojiconsFragment.backspace(inputMsg);
    // }
    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager = (ConnectivityManager) this
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager
                .getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected()
                && activeNetworkInfo.isAvailable();
    }
}
