package com.wenkey.sections.Messages.MessageActivity.view;

/**
 * Created by Ali Assadi on 10/18/2017.
 */

public interface MessageActivityView {
}
