package com.wenkey.utils;

/**
 * Created by Ali Assadi on 10/21/2017.
 */

public class Keys {
    /*SharedPreferences*/
    public static final String SP_MAIN = "sharedPrefsMain";

    /*User*/
    public static final String SP_USER = "spUser";

}
