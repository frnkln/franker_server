package com.wenkey.sections.Profile.EditInfoActivity.view;

/**
 * Created by Ali Assadi on 10/17/2017.
 */

public interface EditInfoActivityView {
    void startWorkActivity();
    void startEducationActivity();
}
