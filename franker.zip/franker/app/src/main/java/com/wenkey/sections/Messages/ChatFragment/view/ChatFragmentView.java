package com.wenkey.sections.Messages.ChatFragment.view;

/**
 * Created by Ali Assadi on 10/16/2017.
 */

public interface ChatFragmentView {
}
