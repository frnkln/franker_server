package com.wenkey.franksocket.Model;

public class WsConfig {

	// THIS is LOCAL VIRTUAL MACHINE STUFF
//	
//	 public static final String URL_WEBSOCKET_GROUP = "ws://192.168.42.111:8080/chatall/groupchat?name=";
//	 public static final String URL_WEBSOCKET_PRIVATE = "ws://192.168.42.111:8080/chatall/chat/";
//	 public static final String URL_REGISTRATION = "http://192.168.42.111:8080/chatall/LoginServlet";
//	 public static final String URL_LOGINVALIDATION = "http://192.168.42.111:8080/chatall/LoginValidationServlet";
//	 public static final String URL_ACCOUNTINFO = "http://192.168.42.111:8080/chatall/getUserDetailsServlet";
//	 public static final String URL_STATUSUPDATE = "http://192.168.42.111:8080/chatall/StstusUpdateServlet";
//	 public static final String URL_POSTUPDATE = "http://192.168.42.111:8080/chatall/postUpdateServlet";
//	 public static final String URL_POSTDELETE = "http://192.168.42.111:8080/chatall/PostDeleteServlet";
//	 public static final String URL_FRIENDDELETE = "http://192.168.42.111:8080/chatall/FriendDeleteServlet";
//	 public static final String URL_ALLUSERS = "http://192.168.42.111:8080/chatall/AllUsersServlet";
//	 public static final String URL_FRIENDREQ = "http://192.168.42.111:8080/chatall/FriendReqServlet";
//	 public static final String URL_IMAGE_UPDATION = "http://192.168.42.111:8080/chatall/ImageUpdationServlet";
//	 public static final String URL_FRACCEPTREJECT = "http://192.168.42.111:8080/chatall/AcceptFriendREQServlet";
//	 public static final String URL_PREACH = "http://192.168.42.111:8080/chatall/PreachServlet";
//	 public static final String URL_IMAGEALONE = "http://192.168.42.111:8080/chatall/getImageAloneServlet";
//	 public static final String URL_CHECKSEARCHFRIEND = "http://192.168.42.111:8080/chatall/FriendNameCheckServlet";
//	 public static final String URL_DELETE_ACCOUNT = "http://192.168.42.111:8080/chatall/DeleteAccountServlet";
//	 public static final String URL_CHANGE_PASSWORD = "http://192.168.42.111:8080/chatall/ChangePasswordServlet";
//     public static final String URL_DELETE_FORUM_MESSAGE = "http://192.168.42.111:8080/chatall/DeleteForumServlet";
//      public static final String URL_SETIMAGEALONE = "http://192.168.42.111:8080/chatall/setImageAloneServlet";
//	  public static final String URL_NAMEALONEREGISTER = "http://192.168.42.111:8080/chatall/NameOnlyRegisterServlet";
	
	
	// THIS is OPENSHIFT STUFF
  
//	public static final String URL_WEBSOCKET = "ws://jesusforum-serverhelp.rhcloud.com:8000/chat?name=";
	
//	public static final String URL_WEBSOCKET = "ws://kill-jesusfrankserver.rhcloud.com:8000/chat?name=";
	
	
	// New local machine
	public static final String URL_WEBSOCKET_GROUP = "ws://localhost:8080/Franker/groupchat?name=";
	
// THIS is GOOGLE VIRTUAL MACHINE STUFF

 //    public static final String URL_WEBSOCKET_GROUP = "ws://104.197.23.200:80/chatall/groupchat?name=";
	 public static final String URL_WEBSOCKET_PRIVATE = "ws://104.197.23.200:80/chatall/chat/";
	 public static final String URL_REGISTRATION = "http://104.197.23.200:80/chatall/LoginServlet";
	 public static final String URL_LOGINVALIDATION = "http://104.197.23.200:80/chatall/LoginValidationServlet";
	 public static final String URL_ACCOUNTINFO = "http://104.197.23.200:80/chatall/getUserDetailsServlet";
	 public static final String URL_STATUSUPDATE = "http://104.197.23.200:80/chatall/StstusUpdateServlet";
	 public static final String URL_POSTUPDATE = "http://104.197.23.200:80/chatall/postUpdateServlet";
	 public static final String URL_POSTDELETE = "http://104.197.23.200:80/chatall/PostDeleteServlet";
	 public static final String URL_FRIENDDELETE = "http://104.197.23.200:80/chatall/FriendDeleteServlet";
	 public static final String URL_ALLUSERS = "http://104.197.23.200:80/chatall/AllUsersServlet";
	 public static final String URL_FRIENDREQ = "http://104.197.23.200:80/chatall/FriendReqServlet";
	 public static final String URL_IMAGE_UPDATION = "http://104.197.23.200:80/chatall/ImageUpdationServlet";
	 public static final String URL_FRACCEPTREJECT = "http://104.197.23.200:80/chatall/AcceptFriendREQServlet";
	 public static final String URL_PREACH = "http://104.197.23.200:80/chatall/PreachServlet";
	 public static final String URL_IMAGEALONE = "http://104.197.23.200:80/chatall/getImageAloneServlet";
	 public static final String URL_CHECKSEARCHFRIEND = "http://104.197.23.200:80/chatall/FriendNameCheckServlet";
	 public static final String URL_DELETE_ACCOUNT = "http://104.197.23.200:80/chatall/DeleteAccountServlet";   
	 public static final String URL_CHANGE_PASSWORD = "http://104.197.23.200:80/chatall/ChangePasswordServlet";
     public static final String URL_DELETE_FORUM_MESSAGE = "http://104.197.23.200:80/chatall/DeleteForumServlet";
     public static final String URL_SETIMAGEALONE = "http://104.197.23.200:80/chatall/setImageAloneServlet";
     public static final String URL_NAMEALONEREGISTER = "http://104.197.23.200:80/chatall/NameOnlyRegisterServlet";
}