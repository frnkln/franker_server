package com.wenkey.sections.Profile.AccountFragment.view;

/**
 * Created by Ali Assadi on 10/16/2017.
 */

public interface AccountFragmentView {
    void goToEditInfo();
    void goToSetting();
}
