package com.wenkey.sections.Profile.EducationActivity.view;

/**
 * Created by Ali Assadi on 10/20/2017.
 */

public interface EducationActivityView {
}
