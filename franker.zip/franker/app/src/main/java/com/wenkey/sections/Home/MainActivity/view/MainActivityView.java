package com.wenkey.sections.Home.MainActivity.view;

import android.support.design.widget.TabLayout;

/**
 * Created by Ali Assadi on 10/15/2017.
 */

public interface MainActivityView {
    void selectTab(TabLayout.Tab tab);
    void unSelectTab(TabLayout.Tab tab);
}
