package com.wenkey.sections.Profile.WorkActivity.view;

/**
 * Created by Ali Assadi on 10/20/2017.
 */

public interface WorkActivityView {
}
